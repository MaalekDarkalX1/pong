import turtle

# Setup screen
Wn = turtle.Screen()
Wn.title("Pong by Maalek Darkal")
Wn.bgcolor("black")
Wn.setup(width=900, height=700)
Wn.tracer(0)

# Score
score_x = 0
score_y = 0

# Paddle X (Left)
paddle_x = turtle.Turtle()
paddle_x.speed(0)
paddle_x.shape("square")
paddle_x.color("blue")
paddle_x.shapesize(stretch_wid=5, stretch_len=1)
paddle_x.penup()
paddle_x.goto(-350, 0)

# Paddle Y (Right)
paddle_y = turtle.Turtle()
paddle_y.speed(0)
paddle_y.shape("square")
paddle_y.color("red")
paddle_y.shapesize(stretch_wid=5, stretch_len=1)
paddle_y.penup()
paddle_y.goto(350, 0)

# Ball
ball = turtle.Turtle()
ball.speed(40)
ball.shape("square")
ball.color("white")
ball.penup()
ball.goto(0, 0)
ball.dx = 1.05
ball.dy = 1.05

import random
colors = ["white", "yellow", "green", "blue", "red", "purple", "orange", "pink", "cyan", "magenta"]
ball.color(random.choice(colors))

# Pen (scoreboard)
pen = turtle.Turtle()
pen.speed(0)
pen.color("white")
pen.penup()
pen.hideturtle()
pen.goto(0, 260)
pen.write("Player A: 0  Player B: 0", align="center", font=("Courier", 24, "normal"))

pen2 = turtle.Turtle()
pen2.speed(0)
pen2.color("yellow")
pen2.penup()
pen2.hideturtle()
pen2.goto(0, 230)
pen2.write("first to 10 points wins!", align="center", font=("courier", 18, "normal"))


# Functions
def paddle_x_up():
    y = paddle_x.ycor()
    y += 20
    paddle_x.sety(y)

def paddle_x_down():
    y = paddle_x.ycor()
    y -= 20
    paddle_x.sety(y)

def paddle_y_up():
    y = paddle_y.ycor()
    y += 20
    paddle_y.sety(y)

def paddle_y_down():
    y = paddle_y.ycor()
    y -= 20
    paddle_y.sety(y)

# Keyboard bindings
Wn.listen()
Wn.onkeypress(paddle_x_up, "w")
Wn.onkeypress(paddle_x_down, "s")
Wn.onkeypress(paddle_y_up, "Up")
Wn.onkeypress(paddle_y_down, "Down")

# Main game loop
while True:
    Wn.update()

    # Move the ball
    ball.setx(ball.xcor() + ball.dx)
    ball.sety(ball.ycor() + ball.dy)

    # Border check
    if ball.ycor() > 340:
        ball.sety(340)
        ball.dy *= -1

    if ball.ycor() < -340:
        ball.sety(-340)
        ball.dy *= -1

    if ball.xcor() > 440:
        ball.goto(0, 0)
        ball.dx *= -1
        score_x += 1
        pen.clear()
        pen.write("Player 1: {}  Player 2: {}".format(score_x, score_y), align="center", font=("Courier", 24, "normal"))

    if ball.xcor() < -440:
        ball.goto(0, 0)
        ball.dx *= -1
        score_y += 1
        pen.clear()
        pen.write("Player 1: {}  Player 2: {}".format(score_x, score_y), align="center", font=("Courier", 24, "normal"))

    # Paddle collisions
    if (340 < ball.xcor() < 350) and (paddle_y.ycor() - 50 < ball.ycor() < paddle_y.ycor() + 50):
        ball.setx(340)
        ball.dx *= -1

    if (-350 < ball.xcor() < -340) and (paddle_x.ycor() - 50 < ball.ycor() < paddle_x.ycor() + 50):
        ball.setx(-340)
        ball.dx *= -1