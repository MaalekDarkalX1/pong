import turtle
import random
import time

# Configuration
WIN_WIDTH = 900
WIN_HEIGHT = 600
PADDLE_STRETCH_WID = 6  # shapesize stretch (height units)
PADDLE_HALF = 20 * PADDLE_STRETCH_WID / 2  # half paddle height in pixels (20 px per turtle unit)
PADDLE_X_OFFSET = 400
PADDLE_SPEED = 20  # pixels per key press
INIT_BALL_SPEED = 3.0
HIT_SPEED_MULTIPLIER = 1.05

# Setup screen
wn = turtle.Screen()
wn.title("Pong by Maalek Darkal")
wn.bgcolor("black")
wn.setup(width=WIN_WIDTH, height=WIN_HEIGHT)
wn.tracer(0)

# Score
score_a = 0
score_b = 0

# Paddle A (left)
paddle_a = turtle.Turtle()
paddle_a.speed(0)
paddle_a.shape("square")
paddle_a.color("blue")
paddle_a.shapesize(stretch_wid=PADDLE_STRETCH_WID, stretch_len=1)
paddle_a.penup()
paddle_a.goto(-PADDLE_X_OFFSET, 0)

# Paddle B (right)
paddle_b = turtle.Turtle()
paddle_b.speed(0)
paddle_b.shape("square")
paddle_b.color("red")
paddle_b.shapesize(stretch_wid=PADDLE_STRETCH_WID, stretch_len=1)
paddle_b.penup()
paddle_b.goto(PADDLE_X_OFFSET, 0)

# Ball
ball = turtle.Turtle()
ball.speed(0)
ball.shape("circle")
ball.color("white")
ball.penup()
ball.goto(0, 0)
ball.dx = random.choice([-1, 1]) * INIT_BALL_SPEED
ball.dy = random.choice([-1, 1]) * INIT_BALL_SPEED

# Pen (scoreboard)
pen = turtle.Turtle()
pen.speed(0)
pen.color("white")
pen.penup()
pen.hideturtle()
pen.goto(0, WIN_HEIGHT/2 - 40)
pen.write("Player A: 0  Player B: 0", align="center", font=("Courier", 24, "normal"))

# Info pen
pen2 = turtle.Turtle()
pen2.speed(0)
pen2.color("yellow")
pen2.penup()
pen2.hideturtle()
pen2.goto(0, WIN_HEIGHT/2 - 80)
pen2.write("First to 10 wins!", align="center", font=("Courier", 18, "normal"))

# Movement limits
Y_LIMIT = (WIN_HEIGHT / 2) - PADDLE_HALF  # paddle center y must be <= Y_LIMIT

# Paddle movement functions
def paddle_a_up():
    y = paddle_a.ycor()
    y = min(y + PADDLE_SPEED, Y_LIMIT)
    paddle_a.sety(y)

def paddle_a_down():
    y = paddle_a.ycor()
    y = max(y - PADDLE_SPEED, -Y_LIMIT)
    paddle_a.sety(y)

def paddle_b_up():
    y = paddle_b.ycor()
    y = min(y + PADDLE_SPEED, Y_LIMIT)
    paddle_b.sety(y)

def paddle_b_down():
    y = paddle_b.ycor()
    y = max(y - PADDLE_SPEED, -Y_LIMIT)
    paddle_b.sety(y)

# Keyboard bindings
wn.listen()
wn.onkeypress(paddle_a_up, "w")
wn.onkeypress(paddle_a_down, "s")
wn.onkeypress(paddle_b_up, "Up")
wn.onkeypress(paddle_b_down, "Down")

# Game loop
game_running = True
while game_running:
    wn.update()

    # Move the ball
    ball.setx(ball.xcor() + ball.dx)
    ball.sety(ball.ycor() + ball.dy)

    # Top/bottom collision
    if ball.ycor() > (WIN_HEIGHT/2 - 10):
        ball.sety(WIN_HEIGHT/2 - 10)
        ball.dy *= -1
        # add slight randomness so it doesn't repeat the same path
        ball.dx += random.uniform(-0.3, 0.3)

    
