# pong.py - minimal clean working version
import turtle
import random
import time

def main():
    # Setup screen
    wn = turtle.Screen()
    wn.title("Pong by Maalek Darkal")
    wn.bgcolor("black")
    wn.setup(width=900, height=700)
    wn.tracer(0)

# Intro menu
    mode = wn.textinput("game mode", "select mode:\n1 single player (vs AI)\2 - Multiplayer (2 players)\nEnter 1 or 2:")

# Validate mode
    if mode not in ["1", "2"]:
        mode = "1" # set default to single player if the point is invalid

    ai_enabled = (mode == "1")
    ai_speed = 0
    ai_mistakes = 0.0
    difficulties_name = ""

#  if single player is selected, choose difficulty
    if ai_enabled:
        difficulties = {
         "1": ("Easy", 6, 0.20),
         "2": ("Medium", 10, 0.07),
         "3": ("Hard", 15, 0.02),
         "4": ("Impossible", 25, 0.0)
        }

    choice = wn.textinput("select difficulty",
                          "Choose AI Difficulty:\n1 - Easy\n2 - Medium\n3 - Hard\n4 -Impossible\nEnter 1-4")
    if choice not in difficulties:
        choice = "2" # The default AI difficulty is Medium if the input is invalid
    
    difficulties_name, ai_speed, ai_mistakes = difficulties[choice]


 # Scores
    score_a = 0
    score_b = 0

    # Paddle settings
    PADDLE_MOVE = 30
    PADDLE_LIMIT = 260

    # Paddle A (left / player 1)
    paddle_a = turtle.Turtle()
    paddle_a.speed(0)
    paddle_a.shape("square")
    paddle_a.color("blue")
    paddle_a.shapesize(stretch_wid=5, stretch_len=1)
    paddle_a.penup()
    paddle_a.goto(-350, 0)

    # Paddle B (right / player 2 or AI)
    paddle_b = turtle.Turtle()
    paddle_b.speed(0)
    paddle_b.shape("square")
    paddle_b.color("red")
    paddle_b.shapesize(stretch_wid=5, stretch_len=1)
    paddle_b.penup()
    paddle_b.goto(350, 0)

    # Ball
    ball = turtle.Turtle()
    ball.speed(0)
    ball.shape("circle")
    ball.color("grey")
    ball.penup()
    ball.goto(0, 0)
    # initial speed and random direction
    INIT_SPEED = 4.0
    ball.dx = INIT_SPEED * random.choice([-1, 1])
    ball.dy = INIT_SPEED * random.choice([-1, 1])

    # Scoreboard pen
    pen = turtle.Turtle()
    pen.speed(0)
    pen.color("white")
    pen.penup()
    pen.hideturtle()
    pen.goto(0, 300)
    pen.write("Player A: 0  Player B: 0", align="center", font=("Courier", 24, "normal"))

    # Info text
    info = turtle.Turtle()
    info.speed(0)
    info.color("yellow")
    info.penup()
    info.hideturtle()
    info.goto(0, 270)
    
    if ai_enabled:
        info.write(f"First to 10 points wins!  Difficulty: {difficulties_name}", align="center", font=("Courier", 18, "normal"))
    else:
        info.write("First to 10 points wins! Multiplayer Mode", align="center", font=("Courier", 18, "normal"))

    # Player Movement Functions
    def paddle_a_up():
        y = paddle_a.ycor()
        if y < PADDLE_LIMIT:
            paddle_a.sety(y + PADDLE_MOVE)

    def paddle_a_down():
        y = paddle_a.ycor()
        if y > -PADDLE_LIMIT:
            paddle_a.sety(y - PADDLE_MOVE)

    def paddle_b_up():
        y = paddle_b.ycor()
        if y < PADDLE_LIMIT:
            paddle_b.sety(y + PADDLE_MOVE)

    def paddle_b_down():
        y = paddle_b.ycor()
        if y > -PADDLE_LIMIT:
            paddle_b.sety(y - PADDLE_MOVE)

    # Keyboard controls
    wn.listen()
    wn.onkeypress(paddle_a_up, "W")
    wn.onkeypress(paddle_a_down, "S")

    if not ai_enabled:   # only eligible in multiplayer mode
        wn.onkeypress(paddle_b_up, "Up")
        wn.onkeypress(paddle_b_down, "Down")


    # Game loop
    while True:
        wn.update()

        # Move ball
        ball.setx(ball.xcor() + ball.dx)
        ball.sety(ball.ycor() + ball.dy)

        # AI BOT for paddle B (only in single player mode)
        # only move when ball is moving toward right side
        if ball.dx > 0:
            if random.random() > ai_mistakes:
                if paddle_b.ycor() < ball.ycor() -10:
                    paddle_b.sety(paddle_b.ycor() + ai_speed)
                elif paddle_b.ycor() > ball.ycor() +10:
                    paddle_b.sety(paddle_b.ycor() - ai_speed)

        else:   # When ball is moving away
            #return ball to centre when going away
            if paddle_b.ycor() > 0:
                paddle_b.sety(paddle_b.ycor() - ai_speed / 2)
            elif paddle_b.ycor()< 0:
                paddle_b.sety(paddle_b.ycor() + ai_speed / 2)
        
        #keeping AI paddle in bounds
        if paddle_b.ycor() > PADDLE_LIMIT :
            paddle_b.sety(PADDLE_LIMIT)
        elif paddle_b.ycor() < -PADDLE_LIMIT:
            paddle_b.sety(-PADDLE_LIMIT)
       
       
        # Top/bottom bounce
        if ball.ycor() > 340:
            ball.sety(340)
            ball.dy *= -1
            ball.dx += random.uniform(-0.4, 0.4)

        if ball.ycor() < -340:
            ball.sety(-340)
            ball.dy *= -1
            ball.dx += random.uniform(-0.4, 0.4)

        # Scoring

        # Right wall (player A scores)
        if ball.xcor() > 440:
            score_a += 1
            pen.clear()
            pen.write("Player A: {}  Player B: {}".format(score_a, score_b),
                      align="center", font=("Courier", 24, "normal"))
            ball.goto(0, 0)
            # reset direction toward left
            ball.dx = -INIT_SPEED
            ball.dy = INIT_SPEED * random.choice([-1, 1])
            time.sleep(0.4)

        # Left wall (player B / AI scores)
        if ball.xcor() < -440:
            score_b += 1
            pen.clear()
            pen.write("Player A: {}  Player B: {}".format(score_a, score_b),
                      align="center", font=("Courier", 24, "normal"))
            ball.goto(0, 0)
            ball.dx = INIT_SPEED
            ball.dy = INIT_SPEED * random.choice([-1, 1])
            time.sleep(0.4)

        # Paddle B collision (right)
        if (ball.xcor() > 320 and ball.xcor() < 360) and \
           (ball.ycor() < paddle_b.ycor() + 60 and ball.ycor() > paddle_b.ycor() - 60):
            ball.setx(320)
            ball.dx *= -1
            ball.dy += random.uniform(-1.0, 1.0)
            ball.dx *= 1.05

        # Paddle A collision (left)
        if (ball.xcor() < -320 and ball.xcor() > -360) and \
           (ball.ycor() < paddle_a.ycor() + 60 and ball.ycor() > paddle_a.ycor() - 60):
            ball.setx(-320)
            ball.dx *= -1
            ball.dy += random.uniform(-1.0, 1.0)
            ball.dx *= 1.05

        # Check Winner
        if score_a >= 10:
            pen.clear()
            info.clear()
            pen.goto(0, 0)
            pen.color("yellow")
            pen.write("PLAYER A wins!", align="center", font=("Courier", 36, "bold"))
            wn.update()
            time.sleep(3)
            return

        if score_b >= 10:
            pen.clear()
            info.clear()
            pen.goto(0, 0)
            pen.color("yellow")
            pen.write("PLAYER B WINS!", align="center", font=("Courier", 36, "bold"))
            wn.update()
            time.sleep(3)
            return

if __name__ == "__main__":
    main()