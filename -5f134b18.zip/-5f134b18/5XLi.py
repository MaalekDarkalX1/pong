import turtle
import random
import time

# Set up the screen
wn = turtle.Screen()
wn.title("Pong by Maalek Darkal 🏓")
wn.bgcolor("black")
wn.setup(width=900, height=600)
wn.tracer(0)

# Score
score_x = 0
score_y = 0

# Paddle A
paddle_a = turtle.Turtle()
paddle_a.speed(0)
paddle_a.shape("square")
paddle_a.color("blue")
paddle_a.shapesize(stretch_wid=6, stretch_len=1)
paddle_a.penup()
paddle_a.goto(-400, 0)

# Paddle B
paddle_b = turtle.Turtle()
paddle_b.speed(0)
paddle_b.shape("square")
paddle_b.color("red")
paddle_b.shapesize(stretch_wid=6, stretch_len=1)
paddle_b.penup()
paddle_b.goto(400, 0)

# Ball
ball = turtle.Turtle()
ball.speed(0)
ball.shape("circle")
ball.color("white")
ball.penup()
ball.goto(0, 0)
ball.dx = 0.4  # faster ball
ball.dy = 0.4

# Pen for score
pen = turtle.Turtle()
pen.speed(0)
pen.color("white")
pen.penup()
pen.hideturtle()
pen.goto(0, 260)
pen.write("Player A: 0  Player B: 0", align="center", font=("Courier", 24, "normal"))

# Pen for info text
pen2 = turtle.Turtle()
pen2.speed(0)
pen2.color("yellow")
pen2.penup()
pen2.hideturtle()
pen2.goto(0, 230)
pen2.write("First to 10 wins!", align="center", font=("Courier", 18, "normal"))

# Paddle movement
paddle_speed = 35  # faster paddles

def paddle_a_up():
    y = paddle_a.ycor()
    if y < 250:  # stop at top edge
        y += paddle_speed
        paddle_a.sety(y)

def paddle_a_down():
    y = paddle_a.ycor()
    if y > -250:  # stop at bottom edge
        y -= paddle_speed
        paddle_a.sety(y)

def paddle_b_up():
    y = paddle_b.ycor()
    if y < 250:
        y += paddle_speed
        paddle_b.sety(y)

def paddle_b_down():
    y = paddle_b.ycor()
    if y > -250:
        y -= paddle_speed
        paddle_b.sety(y)

# Keyboard bindings
wn.listen()
wn.onkeypress(paddle_a_up, "w")
wn.onkeypress(paddle_a_down, "s")
wn.onkeypress(paddle_b_up, "Up")
wn.onkeypress(paddle_b_down, "Down")

# Game loop
while True:
    wn.update()

    # Move the ball
    ball.setx(ball.xcor() + ball.dx)
    ball.sety(ball.ycor() + ball.dy)

    # Border check (top/bottom)
    if ball.ycor() > 290:
        ball.sety(290)
        ball.dy *= -1
        ball.dx += random.choice([-0.02, 0.02])  # make bounce unpredictable
        ball.dy += random.choice([-0.02, 0.02])

    if ball.ycor() < -290:
        ball.sety(-290)
        ball.dy *= -1
        ball.dx += random.choice([-0.02, 0.02])
        ball.dy += random.choice([-0.02, 0.02])

    # Right border
    if ball.xcor() > 440:
        ball.goto(0, 0)
        ball.dx = -0.4
        ball.dy = random.choice([-0.4, 0.4])
        score_x += 1
        pen.clear()
        pen.write("Player A: {}  Player B: {}".format(score_x, score_y), align="center", font=("Courier", 24, "normal"))
        time.sleep(0.5)

    # Left border
    if ball.xcor() < -440:
        ball.goto(0, 0)
        ball.dx = 0.4
        ball.dy = random.choice([-0.4, 0.4])
        score_y += 1
        pen.clear()
        pen.write("Player A: {}  Player B: {}".format(score_x, score_y), align="center", font=("Courier", 24, "normal"))
        time.sleep(0.5)

    # Paddle and ball collisions
    if (ball.xcor() > 380 and ball.xcor() < 390) and (ball.ycor() < paddle_b.ycor() + 50 and ball.ycor() > paddle_b.ycor() - 50):
        ball.setx(380)
        ball.dx *= -1
        ball.dx += random.choice([-0.02, 0.02])
        ball.dy += random.choice([-0.02, 0.02])

    if (ball.xcor() < -380 and ball.xcor() > -390) and (ball.ycor() < paddle_a.ycor() + 50 and ball.ycor() > paddle_a.ycor() - 50):
        ball.setx(-380)
        ball.dx *= -1
        ball.dx += random.choice([-0.02, 0.02])
        ball.dy += random.choice([-0.02, 0.02])

    # Check for winner
    if score_x == 10:
        pen.clear()
        pen2.clear()
        pen.goto(0, 0)
        pen.color("yellow")
        pen.write("🏆 Player A Wins! 🏆", align="center", font=("Courier", 36, "bold"))
        break

    if score_y == 10:
        pen.clear()
        pen2.clear()
        pen.goto(0, 0)
        pen.color("yellow")
        pen.write("🏆 Player B Wins! 🏆", align="center", font=("Courier", 36, "bold"))
        break
