import turtle
import random

# Screen setup
win = turtle.Screen()
win.title("Pong by Maalek")
win.bgcolor("black")
win.setup(width=800, height=600)
win.tracer(0)

# Score
score_a = 0
score_b = 0

# Paddle A
paddle_a = turtle.Turtle()
paddle_a.speed(0)
paddle_a.shape("square")
paddle_a.color("white")
paddle_a.shapesize(stretch_wid=6, stretch_len=1)
paddle_a.penup()
paddle_a.goto(-350, 0)

# Paddle B
paddle_b = turtle.Turtle()
paddle_b.speed(0)
paddle_b.shape("square")
paddle_b.color("white")
paddle_b.shapesize(stretch_wid=6, stretch_len=1)
paddle_b.penup()
paddle_b.goto(350, 0)

# Ball
ball = turtle.Turtle()
ball.speed(0)
ball.shape("square")
ball.color("white")
ball.penup()
ball.goto(0, 0)
ball.dx = 0.25 * random.choice([-1, 1])
ball.dy = 0.25 * random.choice([-1, 1])

# Pen
pen = turtle.Turtle()
pen.speed(0)
pen.color("white")
pen.penup()
pen.hideturtle()
pen.goto(0, 260)
pen.write("Player A: 0  Player B: 0   (First to 10 Wins!)",
          align="center", font=("Courier", 16, "normal"))

# Paddle movement
paddle_speed = 40

def paddle_a_up():
    y = paddle_a.ycor()
    if y < 250:  # stop at top
        y += paddle_speed
        paddle_a.sety(y)

def paddle_a_down():
    y = paddle_a.ycor()
    if y > -240:  # stop at bottom
        y -= paddle_speed
        paddle_a.sety(y)

def paddle_b_up():
    y = paddle_b.ycor()
    if y < 250:
        y += paddle_speed
        paddle_b.sety(y)

def paddle_b_down():
    y = paddle_b.ycor()
    if y > -240:
        y -= paddle_speed
        paddle_b.sety(y)

# Keyboard bindings
win.listen()
win.onkeypress(paddle_a_up, "w")
win.onkeypress(paddle_a_down, "s")
win.onkeypress(paddle_b_up, "Up")
win.onkeypress(paddle_b_down, "Down")

# Main game loop
while True:
    win.update()

    # Move the ball
    ball.setx(ball.xcor() + ball.dx)
    ball.sety(ball.ycor() + ball.dy)

    # Top and bottom borders
    if ball.ycor() > 290:
        ball.sety(290)
        ball.dy *= -1
        ball.dy += random.uniform(-0.02, 0.02)

    if ball.ycor() < -290:
        ball.sety(-290)
        ball.dy *= -1
        ball.dy += random.uniform(-0.02, 0.02)

    # Ball goes off right
    if ball.xcor() > 390:
        ball.goto(0, 0)
        ball.dx = -0.25 * random.choice([1, -1])
        ball.dy = 0.25 * random.choice([1, -1])
        score_a += 1
        pen.clear()
        pen.write(f"Player A: {score_a}  Player B: {score_b}   (First to 10 Wins!)",
                  align="center", font=("Courier", 16, "normal"))

    # Ball goes off left
    if ball.xcor() < -390:
        ball.goto(0, 0)
        ball.dx = 0.25 * random.choice([1, -1])
        ball.dy = 0.25 * random.choice([1, -1])
        score_b += 1
        pen.clear()
        pen.write(f"Player A: {score_a}  Player B: {score_b}   (First to 10 Wins!)",
                  align="center", font=("Courier", 16, "normal"))

    # Paddle and ball collisions
    if (340 < ball.xcor() < 350) and (paddle_b.ycor() - 60 < ball.ycor() < paddle_b.ycor() + 60):
        ball.setx(340)
        ball.dx *= -1.1
        ball.dy += random.uniform(-0.05, 0.05)

    if (-350 < ball.xcor() < -340) and (paddle_a.ycor() - 60 < ball.ycor() < paddle_a.ycor() + 60):
        ball.setx(-340)
        ball.dx *= -1.1
        ball.dy += random.uniform(-0.05, 0.05)

    # Check for winner
    if score_a == 10:
        pen.clear()
        pen.write("🏆 Player A Wins! 🏆", align="center", font=("Courier", 24, "bold"))
        break

    if score_b == 10:
        pen.clear()
        pen.write("🏆 Player B Wins! 🏆", align="center", font=("Courier", 24, "bold"))
        break

win.mainloop()
