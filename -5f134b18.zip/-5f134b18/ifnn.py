import turtle
import random
import time

def main():
    # --- Setup Screen ---
    wn = turtle.Screen()
    wn.title("Pong by Maalek Darkal")
    wn.bgcolor("black")
    wn.setup(width=900, height=700)
    wn.tracer(0)

    # --- INTRO MENU ---
    mode = wn.textinput("Game Mode", "Select mode:\n1 - Single Player (vs AI)\n2 - Multiplayer (2 Players)\nEnter 1 or 2:")

    # Validate mode
    if mode not in ["1", "2"]:
        mode = "1"  # default single player

    ai_enabled = (mode == "1")
    ai_speed = 0
    ai_mistake = 0.0
    difficulty_name = ""

    # --- If Single Player, Choose Difficulty ---
    if ai_enabled:
        difficulties = {
            "1": ("Easy", 6, 0.20),
            "2": ("Medium", 10, 0.07),
            "3": ("Hard", 15, 0.02),
            "4": ("Impossible", 25, 0.0)
        }

        choice = wn.textinput("Select Difficulty",
                              "Choose AI Difficulty:\n1 - Easy\n2 - Medium\n3 - Hard\n4 - Impossible\nEnter 1-4:")
        if choice not in difficulties:
            choice = "2"  # default to Medium

        difficulty_name, ai_speed, ai_mistake = difficulties[choice]

    # --- Scores ---
    score_a = 0
    score_b = 0

    # --- Paddle Settings ---
    PADDLE_MOVE = 30
    PADDLE_LIMIT = 260

    # --- Paddle A (Left / Player 1) ---
    paddle_a = turtle.Turtle()
    paddle_a.speed(0)
    paddle_a.shape("square")
    paddle_a.color("blue")
    paddle_a.shapesize(stretch_wid=5, stretch_len=1)
    paddle_a.penup()
    paddle_a.goto(-350, 0)

    # --- Paddle B (Right / Player 2 or AI) ---
    paddle_b = turtle.Turtle()
    paddle_b.speed(0)
    paddle_b.shape("square")
    paddle_b.color("red")
    paddle_b.shapesize(stretch_wid=5, stretch_len=1)
    paddle_b.penup()
    paddle_b.goto(350, 0)

    # --- Ball ---
    ball = turtle.Turtle()
    ball.speed(0)
    ball.shape("circle")
    ball.color("grey")
    ball.penup()
    ball.goto(0, 0)
    INIT_SPEED = 4.0
    ball.dx = INIT_SPEED * random.choice([-1, 1])
    ball.dy = INIT_SPEED * random.choice([-1, 1])

    # --- Scoreboard ---
    pen = turtle.Turtle()
    pen.speed(0)
    pen.color("white")
    pen.penup()
    pen.hideturtle()
    pen.goto(0, 300)
    pen.write("Player A: 0  Player B: 0", align="center", font=("Courier", 24, "normal"))

    # --- Info Text ---
    info = turtle.Turtle()
    info.speed(0)
    info.color("yellow")
    info.penup()
    info.hideturtle()
    info.goto(0, 270)

    if ai_enabled:
        info.write(f"First to 10 wins!  Difficulty: {difficulty_name}", align="center", font=("Courier", 18, "normal"))
    else:
        info.write("First to 10 wins!  Multiplayer Mode", align="center", font=("Courier", 18, "normal"))

    # --- Player Movement Functions ---
    def paddle_a_up():
        y = paddle_a.ycor()
        if y < PADDLE_LIMIT:
            paddle_a.sety(y + PADDLE_MOVE)

    def paddle_a_down():
        y = paddle_a.ycor()
        if y > -PADDLE_LIMIT:
            paddle_a.sety(y - PADDLE_MOVE)

    def paddle_b_up():
        y = paddle_b.ycor()
        if y < PADDLE_LIMIT:
            paddle_b.sety(y + PADDLE_MOVE)

    def paddle_b_down():
        y = paddle_b.ycor()
        if y > -PADDLE_LIMIT:
            paddle_b.sety(y - PADDLE_MOVE)

    # --- Keyboard Controls ---
    wn.listen()
    wn.onkeypress(paddle_a_up, "w")
    wn.onkeypress(paddle_a_down, "s")

    if not ai_enabled:  # multiplayer
        wn.onkeypress(paddle_b_up, "Up")
        wn.onkeypress(paddle_b_down, "Down")

    # --- GAME LOOP ---
    while True:
        wn.update()

        # Move ball
        ball.setx(ball.xcor() + ball.dx)
        ball.sety(ball.ycor() + ball.dy)

        # --- AI Movement (only in single-player) ---
        if ai_enabled:
            if ball.dx > 0:  # ball moving toward AI
                if random.random() > ai_mistake:
                    if paddle_b.ycor() < ball.ycor() - 10:
                        paddle_b.sety(paddle_b.ycor() + ai_speed)
                    elif paddle_b.ycor() > ball.ycor() + 10:
                        paddle_b.sety(paddle_b.ycor() - ai_speed)
            else:  # ball going away, AI recenters
                if paddle_b.ycor() > 0:
                    paddle_b.sety(paddle_b.ycor() - ai_speed / 2)
                elif paddle_b.ycor() < 0:
                    paddle_b.sety(paddle_b.ycor() + ai_speed / 2)

        # Keep paddles inside bounds
        for p in (paddle_a, paddle_b):
            if p.ycor() > PADDLE_LIMIT:
                p.sety(PADDLE_LIMIT)
            elif p.ycor() < -PADDLE_LIMIT:
                p.sety(-PADDLE_LIMIT)

        # --- Ball collisions (walls) ---
        if ball.ycor() > 340:
            ball.sety(340)
            ball.dy *= -1
            ball.dx += random.uniform(-0.4, 0.4)

        if ball.ycor() < -340:
            ball.sety(-340)
            ball.dy *= -1
            ball.dx += random.uniform(-0.4, 0.4)

        # --- Scoring ---
        if ball.xcor() > 440:  # Player A scores
            score_a += 1
            pen.clear()
            pen.write(f"Player A: {score_a}  Player B: {score_b}", align="center", font=("Courier", 24, "normal"))
            ball.goto(0, 0)
            ball.dx = -INIT_SPEED
            ball.dy = INIT_SPEED * random.choice([-1, 1])
            time.sleep(0.4)

        if ball.xcor() < -440:  # Player B or AI scores
            score_b += 1
            pen.clear()
            pen.write(f"Player A: {score_a}  Player B: {score_b}", align="center", font=("Courier", 24, "normal"))
            ball.goto(0, 0)
            ball.dx = INIT_SPEED
            ball.dy = INIT_SPEED * random.choice([-1, 1])
            time.sleep(0.4)

        # --- Paddle collisions ---
        if (ball.xcor() > 320 and ball.xcor() < 360) and \
           (ball.ycor() < paddle_b.ycor() + 60 and ball.ycor() > paddle_b.ycor() - 60):
            ball.setx(320)
            ball.dx *= -1
            ball.dy += random.uniform(-1.0, 1.0)
            ball.dx *= 1.05

        if (ball.xcor() < -320 and ball.xcor() > -360) and \
           (ball.ycor() < paddle_a.ycor() + 60 and ball.ycor() > paddle_a.ycor() - 60):
            ball.setx(-320)
            ball.dx *= -1
            ball.dy += random.uniform(-1.0, 1.0)
            ball.dx *= 1.05

        # --- Winner Check ---
        if score_a >= 10:
            pen.clear()
            info.clear()
            pen.goto(0, 0)
            pen.color("yellow")
            pen.write("PLAYER A wins!", align="center", font=("Courier", 36, "bold"))
            wn.update()
            time.sleep(3)
            return

        if score_b >= 10:
            pen.clear()
            info.clear()
            pen.goto(0, 0)
            pen.color("yellow")
            winner = "AI" if ai_enabled else "PLAYER B"
            pen.write(f"{winner} WINS!", align="center", font=("Courier", 36, "bold"))
            wn.update()
            time.sleep(3)
            return


if __name__ == "__main__":
    main()