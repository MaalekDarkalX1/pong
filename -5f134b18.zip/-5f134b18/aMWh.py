import turtle
import random
import time
import math

def main():
    wn = turtle.Screen()
    wn.title("Pong by Maalek Darkal")
    wn.bgcolor("black")
    wn.setup(width=900, height=700)
    wn.tracer(0)

    # --- Menu ---
    mode = wn.textinput("Game Mode", "Select mode:\n1 - Single Player (vs AI)\n2 - Multiplayer (2 Players)\nEnter 1 or 2:")
    if mode not in ["1", "2"]:
        mode = "1"

    ai_enabled = (mode == "1")
    difficulty_name = ""
    ai_speed = 0
    ai_mistake = 0

    if ai_enabled:
        difficulties = {
            "1": ("Easy", 6, 0.25),
            "2": ("Medium", 10, 0.1),
            "3": ("Hard", 14, 0.03),
            "4": ("Impossible", 22, 0.0)
        }
        choice = wn.textinput("Select Difficulty", "1 - Easy\n2 - Medium\n3 - Hard\n4 - Impossible\nEnter 1-4:")
        if choice not in difficulties:
            choice = "2"
        difficulty_name, ai_speed, ai_mistake = difficulties[choice]

    # --- Game setup ---
    score_a = 0
    score_b = 0
    PADDLE_MOVE = 30
    PADDLE_LIMIT = 260

    paddle_a = turtle.Turtle()
    paddle_a.speed(0)
    paddle_a.shape("square")
    paddle_a.color("blue")
    paddle_a.shapesize(stretch_wid=5, stretch_len=1)
    paddle_a.penup()
    paddle_a.goto(-350, 0)

    paddle_b = turtle.Turtle()
    paddle_b.speed(0)
    paddle_b.shape("square")
    paddle_b.color("red")
    paddle_b.shapesize(stretch_wid=5, stretch_len=1)
    paddle_b.penup()
    paddle_b.goto(350, 0)

    ball = turtle.Turtle()
    ball.speed(0)
    ball.shape("circle")
    ball.color("grey")
    ball.penup()
    ball.goto(0, 0)

    INIT_SPEED = 5.0
    ball.dx = INIT_SPEED * random.choice([-1, 1])
    ball.dy = INIT_SPEED * random.choice([-0.5, 0.5])

    pen = turtle.Turtle()
    pen.speed(0)
    pen.color("white")
    pen.penup()
    pen.hideturtle()
    pen.goto(0, 300)
    pen.write("Player A: 0  Player B: 0", align="center", font=("Courier", 24, "normal"))

    info = turtle.Turtle()
    info.speed(0)
    info.color("yellow")
    info.penup()
    info.hideturtle()
    info.goto(0, 270)
    if ai_enabled:
        info.write(f"First to 10 wins! Difficulty: {difficulty_name}", align="center", font=("Courier", 18, "normal"))
    else:
        info.write("First to 10 wins! Multiplayer Mode", align="center", font=("Courier", 18, "normal"))

    # --- Paddle movement ---
    def paddle_a_up():
        y = paddle_a.ycor()
        if y < PADDLE_LIMIT:
            paddle_a.sety(y + PADDLE_MOVE)

    def paddle_a_down():
        y = paddle_a.ycor()
        if y > -PADDLE_LIMIT:
            paddle_a.sety(y - PADDLE_MOVE)

    def paddle_b_up():
        y = paddle_b.ycor()
        if y < PADDLE_LIMIT:
            paddle_b.sety(y + PADDLE_MOVE)

    def paddle_b_down():
        y = paddle_b.ycor()
        if y > -PADDLE_LIMIT:
            paddle_b.sety(y - PADDLE_MOVE)

    wn.listen()
    wn.onkeypress(paddle_a_up, "w")
    wn.onkeypress(paddle_a_down, "s")
    if not ai_enabled:
        wn.onkeypress(paddle_b_up, "Up")
        wn.onkeypress(paddle_b_down, "Down")

    # --- Helpers ---
    def normalize_speed():
        """Keep the ball speed consistent and the angle playable."""
        speed = math.sqrt(ball.dx**2 + ball.dy**2)
        max_angle = math.radians(65)  # Max tilt
        angle = math.atan2(ball.dy, abs(ball.dx))
        if abs(angle) > max_angle:
            new_dy = math.copysign(math.sin(max_angle) * speed, ball.dy)
            new_dx = math.copysign(math.cos(max_angle) * speed, ball.dx)
            ball.dx, ball.dy = new_dx, new_dy

        # Keep total speed in range
        if speed > 12:
            factor = 12 / speed
            ball.dx *= factor
            ball.dy *= factor

    def reset_ball(direction):
        """Reset ball to center and serve in a random fair direction."""
        ball.goto(0, 0)
        ball.dx = INIT_SPEED * direction
        ball.dy = INIT_SPEED * random.choice([-0.5, 0.5])
        normalize_speed()
        time.sleep(0.4)

    # --- Game Loop ---
    while True:
        wn.update()

        # Move ball
        ball.setx(ball.xcor() + ball.dx)
        ball.sety(ball.ycor() + ball.dy)

        # --- AI movement ---
        if ai_enabled:
            #only reacts every few frames depending on the difficulty
            if not hasattr(main, "ai_frame"):
                main.ai_timer = 0
            main.ai_timer += 1

            # AI reaction delay ( Lower = faster)
            reaction_delay = {
                "Easy": 12,
                "medium": 8,
                "Hard": 4,
                "Impossible": 1
            }[difficulty_name]


            # Ajusted speed when ball is too fast
            adjusted_speed = ai_speed * (0.8 if abs(ball.dx) > 10 else 1.0)

            # make bot only track when ball is moving towards it
            if ball.dx > 0:
                target_y = ball.ycor() + random.randint(-error_margin, error_margin)
                if paddle_b.ycor() < target_y -10:
                    paddle_b.sety(paddle_b.ycor() + adjusted_speed)
                elif paddle_b.ycor() > target_y + 10:
                    paddle_b.sety(paddle_b.ycor() - adjusted_speed)
            else:
                # drift toward center slowly when the ball goes away
                if paddle_b.ycor() > 0:
                    paddle_b.sety(paddle_b.ycor() - adjusted_speed / 2)
                elif paddle_b.ycor() < 0:
                    paddle_b.sety(paddle_b.ycor() + adjusted_speed / 2)


        # Keep paddles in bounds
        for p in (paddle_a, paddle_b):
            if p.ycor() > PADDLE_LIMIT:
                p.sety(PADDLE_LIMIT)
            elif p.ycor() < -PADDLE_LIMIT:
                p.sety(-PADDLE_LIMIT)

        # --- Wall bounce ---
        if ball.ycor() > 340:
            ball.sety(340)
            ball.dy *= -1
            normalize_speed()

        if ball.ycor() < -340:
            ball.sety(-340)
            ball.dy *= -1
            normalize_speed()

        # --- Scoring ---
        if ball.xcor() > 440:
            score_a += 1
            pen.clear()
            pen.write(f"Player A: {score_a}  Player B: {score_b}", align="center", font=("Courier", 24, "normal"))
            reset_ball(-1)

        if ball.xcor() < -440:
            score_b += 1
            pen.clear()
            pen.write(f"Player A: {score_a}  Player B: {score_b}", align="center", font=("Courier", 24, "normal"))
            reset_ball(1)

        # --- Paddle collisions (expanded hitboxes) ---
        # Paddle B
        if (310 < ball.xcor() < 370) and (paddle_b.ycor() - 70 < ball.ycor() < paddle_b.ycor() + 70):
            ball.setx(310)
            offset = ball.ycor() - paddle_b.ycor()
            ball.dy = offset / 8
            ball.dx *= -1
            ball.dx *= 1.05
            ball.dy *= 1.05
            normalize_speed()

        # Paddle A
        if (-370 < ball.xcor() < -310) and (paddle_a.ycor() - 70 < ball.ycor() < paddle_a.ycor() + 70):
            ball.setx(-310)
            offset = ball.ycor() - paddle_a.ycor()
            ball.dy = offset / 8
            ball.dx *= -1
            ball.dx *= 1.05
            ball.dy *= 1.05
            normalize_speed()

        # --- Winner check ---
        if score_a >= 10:
            pen.clear()
            info.clear()
            pen.goto(0, 0)
            pen.color("yellow")
            pen.write("PLAYER A WINS!", align="center", font=("Courier", 36, "bold"))
            wn.update()
            time.sleep(3)
            return

        if score_b >= 10:
            pen.clear()
            info.clear()
            pen.goto(0, 0)
            pen.color("yellow")
            winner = "AI" if ai_enabled else "PLAYER B"
            pen.write(f"{winner} WINS!", align="center", font=("Courier", 36, "bold"))
            wn.update()
            time.sleep(3)
            return

        # Small frame delay to avoid skipping collisions
        time.sleep(0.01)


if __name__ == "__main__":
    main()
