import turtle
import random
import time

# Setup screen
wn = turtle.Screen()
wn.title("Pong by Maalek Darkal")
wn.bgcolor("black")
wn.setup(width=900, height=700)
wn.tracer(0)

# Score
score_a = 0
score_b = 0

# Paddle speed and limits
paddle_speed = 30
paddle_limit = 290  # keeps paddles inside screen

# Paddle A (left)
paddle_a = turtle.Turtle()
paddle_a.speed(0)
paddle_a.shape("square")
paddle_a.color("blue")
paddle_a.shapesize(stretch_wid=5, stretch_len=1)
paddle_a.penup()
paddle_a.goto(-400, 0)

# Paddle B (right)
paddle_b = turtle.Turtle()
paddle_b.speed(0)
paddle_b.shape("square")
paddle_b.color("red")
paddle_b.shapesize(stretch_wid=5, stretch_len=1)
paddle_b.penup()
paddle_b.goto(400, 0)

# Ball
ball = turtle.Turtle()
ball.speed(0)
ball.shape("square")
ball.color("white")
ball.penup()
ball.goto(0, 0)
ball.dx = 4   # horizontal speed
ball.dy = 3   # vertical speed

# Scoreboard
pen = turtle.Turtle()
pen.speed(0)
pen.color("white")
pen.penup()
pen.hideturtle()
pen.goto(0, 260)
pen.write("Player A: 0  Player B: 0", align="center", font=("Courier", 24, "normal"))

# “First to 10 wins” text
pen2 = turtle.Turtle()
pen2.speed(0)
pen2.color("yellow")
pen2.penup()
pen2.hideturtle()
pen2.goto(0, 230)
pen2.write("First to 10 wins!", align="center", font=("Courier", 18, "normal"))

# --- Paddle movement ---
def paddle_a_up():
    y = paddle_a.ycor()
    if y < paddle_limit:
        paddle_a.sety(y + paddle_speed)

def paddle_a_down():
    y = paddle_a.ycor()
    if y > -paddle_limit:
        paddle_a.sety(y - paddle_speed)

def paddle_b_up():
    y = paddle_b.ycor()
    if y < paddle_limit:
        paddle_b.sety(y + paddle_speed)

def paddle_b_down():
    y = paddle_b.ycor()
    if y > -paddle_limit:
        paddle_b.sety(y - paddle_speed)

# Keyboard bindings
wn.listen()
wn.onkeypress(paddle_a_up, "w")
wn.onkeypress(paddle_a_down, "s")
wn.onkeypress(paddle_b_up, "Up")
wn.onkeypress(paddle_b_down, "Down")

# --- Main Game Loop ---
game_running = True

while game_running:
    wn.update()

    # Move the ball
    ball.setx(ball.xcor() + ball.dx)
    ball.sety(ball.ycor() + ball.dy)

    # Bounce off top/bottom
    if ball.ycor() > 340:
        ball.sety(340)
        ball.dy *= -1
        ball.dx += random.uniform(-0.3, 0.3)

    if ball.ycor() < -340:
        ball.sety(-340)
        ball.dy *= -1
        ball.dx += random.uniform(-0.3, 0.3)

    # Ball goes past right wall
    if ball.xcor() > 440:
        score_a += 1
        pen.clear()
        pen.write(f"Player A: {score_a}  Player B: {score_b}", align="center", font=("Courier", 24, "normal"))
        ball.goto(0, 0)
        ball.dx = -4
        ball.dy = random.choice([-3, 3])
        time.sleep(0.5)

    # Ball goes past left wall
    if ball.xcor() < -440:
        score_b += 1
        pen.clear()
        pen.write(f"Player A: {score_a}  Player B: {score_b}", align="center", font=("Courier", 24, "normal"))
        ball.goto(0, 0)
        ball.dx = 4
        ball.dy = random.choice([-3, 3])
        time.sleep(0.5)

    # Right paddle collision
    if (ball.xcor() > 380 and ball.xcor() < 390) and (paddle_b.ycor() - 50 < ball.ycor() < paddle_b.ycor() + 50):
        ball.setx(380)
        ball.dx *= -1
        ball.dy += random.uniform(-0.5, 0.5)
        ball.dx *= 1.1  # speed up slightly

    # Left paddle collision
    if (ball.xcor() < -380 and ball.xcor() > -390) and (paddle_a.ycor() - 50 < ball.ycor() < paddle_a.ycor() + 50):
        ball.setx(-380)
        ball.dx *= -1
        ball.dy += random.uniform(-0.5, 0.5)
        ball.dx *= 1.1

    # Check for winner
    if score_a >= 10:
        pen.clear()
        pen2.clear()
        pen.goto(0, 0)
        pen.color("yellow")
        pen.write("PLAYER A WINS!", align="center", font=("Courier", 36, "bold"))
        wn.update()
        time.sleep(3)
        game_running = False

    if score_b >= 10:
        pen.clear()
        pen2.clear()
        pen.goto(0, 0)
        pen.color("yellow")
        pen.write("PLAYER B WINS!", align="center", font=("Courier", 36, "bold"))
        wn.update()
        time.sleep(3)
        game_running = False
